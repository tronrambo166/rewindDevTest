  
<?php $__env->startSection('content'); ?>



<div class="row mx-auto shadow" style="width:90%; background:#161616;">  
         <div class="col-md-3"> 
            <h5 class="text-center mt-2">The Top 20</h5> <hr> 

            <table class="table tabil mb-4 text-white">
  <thead>
    <tr>
      <th scope="col">Position</th>
      <th scope="col">Artist</th>
      <th scope="col">Song</th>
      <th scope="col">Move</th>
    
    </tr>
  </thead>
  <tbody id="songs">

   <?php $__currentLoopData = $static20; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $static): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php $cnt=0; $duplicate =0; ?>
   <?php $__currentLoopData = $lastDay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yester): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php if($static->song == $yester->song): ?>  
<?php if($static->position < $yester->position): ?> 
<?php $pos='up'; $cnt++;?>
<?php elseif($static->position == $yester->position): ?> 
<?php  $pos='-'; $cnt++;?>
<?php else: ?> <?php $pos='down'; $cnt++; ?>
<?php endif; ?>

<?php $__currentLoopData = $static20; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $check): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($check->song == $static->artist): ?>
<?php $duplicate =1; ?>
 <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   <?php if($duplicate==0): ?> <tr id="loading">
     
      <td scope="row" class="text-center"> <?php echo e($static->position); ?> </td>
      
      <?php if($static->song == 'Ayra Starr'): ?>
      <td scope="row" class="text-center"> <?php echo e($static->song); ?> </td>
      <td scope="row" class="text-center"> <?php echo e($static->artist); ?> </td>
        <?php else: ?>
       <td scope="row" class="text-center"> <?php echo e($static->artist); ?> </td>
        <td scope="row" class="text-center"> <?php echo e($static->song); ?> </td>
        <?php endif; ?>
        
         <td id="move<?php echo e($static->id); ?>" scope="row" class="text-center small">
          <?php if($pos=='up'): ?> <i class="fas fa-arrow-alt-circle-up text-success fa-2x"></i>
          <?php elseif($pos=='down'): ?> <i class="fas fa-arrow-alt-circle-down text-danger fa-2x"></i>
          <?php else: ?> -
          <?php endif; ?> 
        </td>
    </tr> <?php endif; ?>


   <?php endif; ?>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if($cnt==0): ?>
    <tr id="loading">
     
      <td scope="row" class="text-center"> <?php echo e($static->position); ?> </td>
       <td scope="row" class="text-center"> <?php echo e($static->artist); ?> </td>
        <td scope="row" class="text-center"> <?php echo e($static->song); ?> </td>
         <td id="move<?php echo e($static->id); ?>" scope="row" class="text-center small"> <i class="fas fa-arrow-alt-circle-up text-success fa-2x"></i> </td>
    </tr>
    
   <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
  </tbody>
</table>

<div class="clearfix py-3"></div>



             </div>  

         <div class="col-md-3"> </div>
           <div class="col-sm-6 text-center" style="background-image: url('images/rewind.png');background-repeat:no-repeat; max-height: 600px; background-size:contain; background-position:center;">
           

          <h2 class="px-4 w-100 d-block  text-left text-dark">

                 

                   <?php if(Session::has('reset')): ?>
                   <div class="alert alert-success" role="alert">
                        <p style="font-size: 14px"; class="m-0"><?php echo e(Session::get('reset')); ?>   <?php Session::forget('reset'); ?> </p> </div>  
                    <?php endif; ?>


                    
              <?php if(Session::has('login_err')): ?>
                   <div class="alert alert-primary" role="alert">
                        <p style="color: red;font-size: 14px"; class="font-weight-bold m-0"><?php echo e(Session::get('login_err')); ?>   <?php Session::forget('login_err'); ?> </p>   </div>  
              <?php endif; ?>
                   


                <?php if(Session::has('email')): ?>
                   <div class="alert alert-danger" role="alert">
                        <p style="font-size: 14px"; class="m-0"><?php echo e(Session::get('email')); ?>   <?php Session::forget('email'); ?> </p>   </div>  
              <?php endif; ?>

                 

                   <!-- <span  style="color: green;" class="">Rewind</span> to Know Your Playback</h2> -->

            
             

           </div>    
          
</div>

<script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>


<script type="text/javascript">
/*
$(window).on("load", getSongs);

function getSongs() {
  var key, value,i=1, j=1,tops=1,dur,p=1;
  var BreakException = {};
  //var stageName=document.getElementById('myStageName').value;

     $.ajax({
            url:"move", 
            method:"GET",
            dataType: 'json',
          success: function(data) {  
            const songs20=data.data;
            const songs_all=data.data2;
            const today=data.today;
            const artists=data.artists;
            const all_titles=data.all_titles;


// Top 20 chart
           Object.entries(songs20).forEach(entry => {
           const [title, pos] = entry;
           console.log(title,pos);
           if(pos=='up')
           $('#move'+p).html('<i class="fas fa-arrow-alt-circle-up text-success fa-2x"></i>'); 
           if(pos=='down')
           $('#move'+p).html('<i class="fas fa-arrow-alt-circle-down text-danger fa-2x"></i>'); 
          if(pos=='not')
           $('#move'+p).html('-'); 
           p++;
          
            
          }); 

            
          },
          error:function(error)
          {console.log(error);}

        });
}
*/

</script>


          <?php $__env->stopSection(); ?>
        
       


<?php echo $__env->make('UserPages.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/muziqind/Radio/resources/views/UserPages/static20.blade.php ENDPATH**/ ?>