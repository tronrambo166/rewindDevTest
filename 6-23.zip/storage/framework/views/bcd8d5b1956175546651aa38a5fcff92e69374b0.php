
<?php
use App\Models\User;
$user=DB::table('users')->where('email',Session::get('logged'))->first();
$stage_name=$user->stage_name;  echo $stage_name; 
$channel_id = 246131;     
?>

<!doctype html>
        <html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf8_decode()">
    <meta name="viewport" content="width=device-width, initial-scale=1">
      <style>

     .tabil{margin: auto; text-align: center; background: aliceblue;}

          .text-center{
          text-align:center;
          }
          .title{
          background-color:#f7f7f7;
          padding-top:15px;
          padding-bottom:5px;
          font-size:25px;
          font-weight:200;
          }
        .text-left{
            text-align:left !important;
        }
        .table td{
        font-size:15px; padding: 20px;
        }
       
        .wrapper {
              display: flex;
            }
        .left-div{
          flex: 0 0 65%;
        }
        .right-div{
           flex: 1;
        }
      </style>

    <title>Breakdown!</title>
  </head>
  <body  width="100%">
    <h2 class="text-center" style="background:black; padding: 15px; color:white;"><?php if($channel_id = 246131): ?>  Radio Station: Radio Jambo <?php endif; ?></h2>

    <h3 class="text-center">Artist: <?php echo e($stage_name); ?> songs breakdown last 5 days</h3>

  <table class="shadow my-3 w-100 bg-white table tabil">
  <thead>
    <tr class=" bg-light w-100">


      <th> Title</th>
      <th> Album</th>
      <th> Duration</th>
      <th> Played on</th>
      <th style="padding-right:15px;"> Released date</th>
     
      
    </tr>
  </thead>
  <tbody> 

    <?php $__currentLoopData = $titles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <?php if($arr['artist']==$stage_name): ?>

    <tr class="border">
      
      
      <td><?php if(isset($arr['title'])): ?> <?php echo e($arr['title']); ?> <?php endif; ?></td>
      <td><?php if(isset($arr['album'])): ?> <?php echo e($arr['album']); ?> <?php endif; ?></td>
      <td><?php if(isset($arr['duration'])): ?> <?php if($arr['duration']<10): ?> <?php echo e($arr['duration']); ?> <?php else: ?> <?php echo e(round($arr['duration']/60)); ?> <?php endif; ?> mins  <?php endif; ?></td>
          
       <td><?php if(isset($arr['timestamp'])): ?> <?php echo e($arr['timestamp']); ?> <?php endif; ?></td>
    <td><?php if(isset($arr['release_date'])): ?> <?php echo e($arr['release_date']); ?> <?php endif; ?></td>
    </tr>

     <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
  </tbody>
</table>


  </body>
</html> <?php  ?>
		
		
	  
		
		
	<?php /**PATH /home1/muziqind/Radio/resources/views/success.blade.php ENDPATH**/ ?>