 
<?php $__env->startSection('content'); ?>



<div class="row mx-auto" style="width:90%; background:#161616;">  
         <div class="col-md-12"> 
            <h3 class="text-center mt-2">Rewind Cloud Radio</h3> <hr>

  <table class="shadow mb-3 w-100  shadow border table tabil text-light" style="width:90%; background:#1e1e1e;">
  <thead>
    <tr class="  w-100">
       <p class="text-left py-3 my-0 bg-dark font-weight-bold text-success h5 pl-2">Radio Jambo</p> 

      <th class="small " scope="col">Now Playing</th>
      <th> Title</th>
      <th> Artist</th>
      <th> Time</th>
     
      
    </tr>
  </thead>
  <tbody>
    <tr class="border">
      
      <td>01</td>
      <td><?php echo e($titles['title']); ?></td>
      <td><?php echo e($titles['artist']); ?></td>
      <td><?php echo e(round($titles['duration']/60)); ?> mins</td>
    </tr>
    
  </tbody>
</table>

<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>
<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>
<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>
<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>

             </div>  

        
</div>



          <?php $__env->stopSection(); ?>
        
       


<?php echo $__env->make('UserPages.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/muziqind/Radio/resources/views/UserPages/live.blade.php ENDPATH**/ ?>