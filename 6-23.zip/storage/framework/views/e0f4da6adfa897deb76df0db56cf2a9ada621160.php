<!DOCTYPE html>
<html lang="en">
  <head>
    <?php echo $__env->make('layout.partials.head_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>

  <body>
  <?php if(!Route::is(['login','register','forgot-password','lock-screen','error-404','error-500'])): ?>
  
  <?php if(Session::has('admin')): ?>
  <?php echo $__env->make('layout.partials.header_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <<?php echo $__env->make('layout.partials.nav_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php endif; ?>
 
 <?php endif; ?>
 
 <!-- Main Wrapper -->
<div class="main-wrapper login-body">
            <div class="login-wrapper">
            	<div class="container">
                	<div class="loginbox">
                    	<div class="login-left">
							<img class="img-fluid" src="../assets_admin/img/logo-white.png" alt="Logo">
                        </div>
                        <div class="login-right">
							<div class="login-right-wrap">

								<p class="text-danger"> <?php if(Session::has('log_err')): ?> <?php echo e(Session::get('log_err')); ?> </p>
								<?php endif; ?>
								<p class="text-success"> <?php if(Session::has('reset')): ?> <?php echo e(Session::get('reset')); ?> </p>
								<?php endif; ?>

								<h1>Login</h1>
								<p class="account-subtitle">Access to our dashboard</p>
								
								<!-- Form -->
								<form action="<?php echo e(route('adminLogin')); ?>"  method="post"> <?php echo csrf_field(); ?>
									<div class="form-group">
										<input name="email" class="form-control" type="text" placeholder="Email">
									</div>
									<div class="form-group">
										<input name="password"class="form-control" type="password" placeholder="Password">
									</div>
									<div class="form-group">
										<button class="btn btn-primary btn-block" type="submit">Login</button>
									</div>
								</form>
								<!-- /Form -->
								
								<div class="text-center forgotpass"><a href="<?php echo e(route('forgot','email')); ?>">Forgot Password?</a></div>
								<div class="login-or">
									<span class="or-line"></span>
									
								</div>
								  
								
								
							</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!-- /Main Wrapper -->

 <?php echo $__env->make('layout.partials.footer_admin-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  </body>
</html>


<?php /**PATH /home1/muziqind/Radio/resources/views/admin/login.blade.php ENDPATH**/ ?>