 
<?php $__env->startSection('page'); ?>

<?php use App\Models\User;
 $thisUser=User::where('email', Session::get('logged'))->first();
 $artist_id=$thisUser->id;
?>


<style type="text/css">
 .borders{border:none;}
 .borders td{font-size: 20px;}
 .borders: hover{background: #3a3838;}
.table td, .table th {
     border-top: none;}
     #login{border: 2px solid red;}
</style>

<div class="row mx-auto" style="width:90%; background:#161616;">  
         <div class="col-md-12"> 

            <h4 class="text-center mt-2 text-light">My Music</h4> <hr> 

            <?php if($errors->any()): ?> <div class="alert text-center alert-danger"> <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  <li><?php echo e($error); ?></li> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  </ul> </div><br />
                <?php endif; ?>

                 <?php if(Session::has('song')): ?> 
                 <div class="alert text-center alert-success"> <ul>
                 <li><?php echo e(Session::get('song')); ?> <?php Session::forget('song'); ?></li>  </ul> </div> <br/>
                 <?php endif; ?>

             <button class=" mx-auto d-block mt-3 mb-4 p-2 w-25 font-weight-bold btn btn-outline-success" type="button" data-target="#musicModal" data-toggle="modal" aria-expanded="false" aria-controls="collapseExample">Upload Music</button>


             <p class="text-left py-3 my-0 bg-dark font-weight-bold text-success h5 pl-2">Recent Music

              <button class=" float-right btn py-0 text-primary" type="button" data-toggle="collapse" data-target="#musicDIv" aria-expanded="false" aria-controls="collapseExample"><i class="fas fa-2x fa-angle-down"></i></button></p> 

  <div id="musicDIv" class="show musics" style="max-height: 400px; overflow-y: scroll;">
  <table class="shadow mb-3 w-100  shadow border-none table tabil text-light" style="width:90%; background:#1e1e1e;">
  <thead>
    <tr class="  w-100">
       

      <th width="5%"> No</th>
      <th> Title</th>
      <th> Album</th>
      <th> Description</th>
     
      
    </tr>
  </thead>
  <tbody> <?php $i=0; ?>
    <?php $__currentLoopData = $musics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $music): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  <?php $i++; ?>
    <tr class="borders">
      
      <td><?php echo e($i); ?></td>
      <td class="text-left pl-5">
        <img src="images/singles/<?php echo e($music->song_art); ?>" width="75px" height="75px">
        &nbsp; <?php echo e($music->title); ?></td>
      <td><?php echo e($music->album); ?></td>
      <td><?php echo e($music->description); ?></td>
    </tr>

   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
  </tbody>
</table>
</div>


  <p class="text-left py-3 my-0 bg-dark font-weight-bold text-success h5 pl-2">Albums

              <button class=" float-right btn py-0 text-primary" type="button" data-toggle="collapse" data-target="#musicDIv" aria-expanded="false" aria-controls="collapseExample"><i class="fas fa-2x fa-angle-down"></i></button></p> 

 <div class="row">

<?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($album->artist_id == $artist_id): ?>
<div class="col-md-2 my-3  shadow rounded mx-3" style="background:#1e1e1e;">
<a href="<?php echo e(route('albumSongs',$album->album_id)); ?>">
<div class="image text-center"> <img class="img-fluid rounded" style="max-width: 165px;min-height: 111px;max-height: 111px;" src="images/albums/<?php echo e($album->image); ?>"></div>
<p  style="font-size: 16px;" class=" w-100 text-light  text-center mt-4 h5"> <?php echo e($album->album_title); ?> </p>
</a>
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </div>


<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>
<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>
<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>

             </div>  

        
</div>


<!-- HIDDEN Artist REG -->
<!-- HIDDEN Artist REG -->


<div  class="modal fade" id="musicModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">

         <div class="card-header w-100">
            <button id="login" onclick="single()" class="w-25 btn   px-4 mr-2"><?php echo e(__('Single')); ?></button>
            <button  id="register" onclick="album()" class="w-25 btn  px-4"><?php echo e(__('Album')); ?></button>

             <?php if(Session::has('email')): ?> <p class="text-danger ml-5"><?php echo e(Session::get('email')); ?> <?php Session::forget('email'); ?> </p> <?php endif; ?>
        </div>

              

        <button type="button" class="m-0 close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
    
    
      <div class="modal-body">

         <!-- single-->

                <div id="singleDiv" class="card-body">
                    <form method="POST" action="<?php echo e(route('singleMp3Upload')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                    <input id="artist_id" hidden type="number"  name="artist_id"   value="<?php echo e($artist_id); ?>" >


                        <div class="row mb-3">
                            <label for="song" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Choose song')); ?> <span title="Required" class="text-danger">*</span></label>

                            <div class="col-md-6">
                                <input accept="audio/*" id="song" type="file" class="form-control <?php $__errorArgs = ['song'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="song"  required autocomplete="song" autofocus>

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                         <div class="row mb-3">
                            <label for="name" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Title')); ?> <span title="Required" class="text-danger">*</span></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title"  required autocomplete="name" autofocus>

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                         <div class="row mb-3">
                            <label for="name" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Album')); ?> <span title="Required" class="text-danger">*</span></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="album"  required autocomplete="name" autofocus>

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>



                        <div class="row mb-3">
                            <label for="email" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Description')); ?> <span title="Required" class="text-danger">(optional)</span></label>

                            <div class="col-md-6">
                                <input id="email" type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" value="<?php echo e(old('email')); ?>"  autocomplete="email">

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Composer')); ?> <span title="Required" class="text-danger">(optional)</span></label>

                            <div class="col-md-6">
                                <input id="password" type="text" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="composer"  autocomplete="new-password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        
                        
                         <div class="row mb-3">
                            <label for="password" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Publisher')); ?> <span title="Required" class="text-danger">(optional)</span></label>

                            <div class="col-md-6">
                                <input id="password" type="text" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="publisher"  autocomplete="new-password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        


                       
                         <div class="row mb-3">
                            <label for="password" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Song art')); ?> <span title="Required" class="text-danger">(optional)</span></label>

                            <div class="col-md-6">
                                 <input required="" type="file" class="form-control" name="song_art"  >

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>




                      <!--    <div class="row mb-3">
                             <label for="password-confirm" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Image')); ?> <span title="Required" class="text-danger">*</span></label>

                            <div class="col-md-6">
                                <input required="" type="file" class="form-control" name="image"  >
                            </div>
                        </div> -->




                        <div class="row mb-4">
                            <div class="col-md-12 ">
                                <button type="submit" class="mt-3 w-25 d-block mx-auto btn btn-outline-success">
                                    <?php echo e(__('Save')); ?>

                                </button>
                            </div>
                            </div> <hr>

                           
                    </form>

                </div>
                <!-- single-->

                  
                     <!-- Album -->

                  <div id="albumDiv" class="collapse card-body">
                      <form method="POST" action="<?php echo e(route('albumUpload')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                    <input id="artist_id" hidden type="number"  name="artist_id"   value="<?php echo e($artist_id); ?>" >


                        <div class="row mb-3">
                            <label for="song" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Choose song')); ?> <span title="Required" class="text-danger">*</span></label>

                            <div class="col-md-6">
                                <input  id="song" type="file" class="form-control " name="song[]" multiple  required >

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                         <div class="row mb-3">
                            <label for="name" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Album Title')); ?> <span title="Required" class="text-danger">*</span></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="album_title"  required autocomplete="name" autofocus>

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                         



                        <div class="row mb-3">
                            <label for="email" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Album Description')); ?> <span title="Required" class="text-danger">(optional)</span></label>

                            <div class="col-md-6">
                                <input id="email" type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="album_description" value="<?php echo e(old('email')); ?>"  autocomplete="email">

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Composer')); ?> <span title="Required" class="text-danger">(optional)</span></label>

                            <div class="col-md-6">
                                <input id="password" type="text" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="composer"  autocomplete="new-password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        
                        
                         <div class="row mb-3">
                            <label for="password" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Publisher')); ?> <span title="Required" class="text-danger">(optional)</span></label>

                            <div class="col-md-6">
                                <input id="password" type="text" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="publisher"  autocomplete="new-password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
 


                        <div class="row mb-3">
                             <label for="password-confirm" class="col-md-4 col-form-label text-md-left"><?php echo e(__('Album Cover')); ?> <span title="Required" class="text-danger">*</span></label>

                            <div class="col-md-6">
                                <input required="" type="file" class="form-control" name="image"  >
                            </div>
                        </div> 




                        <div class="row mb-4">
                            <div class="col-md-12 ">
                                <button type="submit" class="mt-3 w-25 d-block mx-auto btn btn-outline-success">
                                    <?php echo e(__('Save')); ?>

                                </button>
                            </div>
                            </div> <hr>

                           
                    </form>

                </div>

                <!-- Album -->



      </div>
    
    
     
    </div>
  </div>
</div>

<script type="text/javascript">
    $('#login').css('border', '2px solid red');

     function single(){
    $('#register').css('border', 'none');    
    $('#login').css('border', '2px solid red');

    $('#singleDiv').show();
    $('#albumDiv').hide();
    }

     function album(){ 
    $('#login').css('border', 'none');
    $('#register').css('border', '2px solid red');

   $('#singleDiv').hide();
    $('#albumDiv').show();
    
    }

</script>



          <?php $__env->stopSection(); ?>
        
       


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/muziqind/Radio/resources/views/myMusic.blade.php ENDPATH**/ ?>