 
<?php $__env->startSection('page'); ?>

<?php use App\Models\User;
 $thisUser=User::where('email', Session::get('logged'))->first();
 $artist_id=$thisUser->id;
?>


<style type="text/css">
 .borders{border:none;}
 .borders td{font-size: 20px;}
 .borders: hover{background: #3a3838;}
.table td, .table th {
     border-top: none;}
     #login{border: 2px solid red;}
</style>

<div class="row mx-auto" style="width:90%; background:#161616;">  
         <div class="col-md-12"> 

         

            <?php if($errors->any()): ?> <div class="alert text-center alert-danger"> <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  <li><?php echo e($error); ?></li> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  </ul> </div><br />
                <?php endif; ?>

                 <?php if(Session::has('song')): ?> 
                 <div class="alert text-center alert-success"> <ul>
                 <li><?php echo e(Session::get('song')); ?> <?php Session::forget('song'); ?></li>  </ul> </div> <br/>
                 <?php endif; ?>


                    <a class=" mx-auto d-block mt-3 mb-4 p-2 w-25 font-weight-bold btn btn-outline-success" 
                    href="<?php echo e(route('myMusic')); ?>" >Back to Music</a>


             <p class="text-left py-3 my-0 bg-dark font-weight-bold text-light h5 pl-2 mt-5"> Album Title -  <?php $__currentLoopData = $songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <span class="text-success"><?php echo e($title->album_title); ?></span> <?php break; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <button class=" float-right btn py-0 text-primary" type="button" data-toggle="collapse" data-target="#musicDIv" aria-expanded="false" aria-controls="collapseExample"><i class="fas fa-2x fa-angle-down"></i></button></p> 

  <div id="musicDIv" class="show musics" style="max-height: 600px; overflow-y: scroll;">
  <table class="shadow mb-3 w-100  shadow border-none table tabil text-light" style="width:90%; background:#1e1e1e;">
  <thead>
    <tr class="  w-100">
       

      <th width="5%"> No</th>
      <th> Title</th>
      <th> Album</th>
      <th> Description</th>
     
      
    </tr>
  </thead>
  <tbody>
   <?php $i=0; ?>
    <?php $__currentLoopData = $songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $music): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  <?php $i++; ?>
    <tr class="borders">
      
      <td><?php echo e($i); ?></td>
      <td class="text-left pl-5">
        <img src="images/albums/<?php echo e($music->image); ?>" width="75px" height="75px">
        &nbsp;<?php echo e($music->title); ?></td>
      <td><?php echo e($music->album_title); ?></td>
      <td><?php echo e($music->album_description); ?></td>
    </tr>

   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
  </tbody>
</table>
</div>



<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>
<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>
<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>
<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>

             </div>  

        
</div>



<script type="text/javascript">
    $('#login').css('border', '2px solid red');

     function single(){
    $('#register').css('border', 'none');    
    $('#login').css('border', '2px solid red');

    $('#singleDiv').show();
    $('#albumDiv').hide();
    }

     function album(){ 
    $('#login').css('border', 'none');
    $('#register').css('border', '2px solid red');

   $('#singleDiv').hide();
    $('#albumDiv').show();
    
    }

</script>



          <?php $__env->stopSection(); ?>
        
       


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/muziqind/Radio/resources/views/internalAlbumSongs.blade.php ENDPATH**/ ?>